

import os
import json
import asyncio
import re
import io
import aiohttp
from datetime import datetime
import discord
import aiosqlite
from discord.ext import commands
from PIL import Image, ImageDraw, ImageFont, ImageFilter

from discord.ui import (
    Button, Select, LayoutView, Container, TextDisplay, Separator,
    ActionRow, MediaGallery, Section, Thumbnail
)

DB_PATH = "db/welcome.db"
INV_COLOR = 0x2b2d31   
ERROR_COLOR = 0xff4444 
SUCCESS_COLOR = 0x43b581
CB = "```"

E_TICK  = "<a:xtra_tick:1461751725424771138>"
E_CROSS = "<a:xtra_cross:1461758174892916799>"
E_WARN  = "<:warning:1448951779353038949>"
E_DOT   = "<:RightArrow:1511137811418448006>"

os.makedirs("db", exist_ok=True)

def safe_url(url):
    if url and str(url).startswith("http"): return str(url)
    return None

def get_safe_color(val):
    try:
        if val is None: return INV_COLOR
        if isinstance(val, int): return val if 0 <= val <= 0xFFFFFF else INV_COLOR
        if isinstance(val, str):
            s = val.strip().lstrip("#")
            if not s: return INV_COLOR
            parsed = int(s, 16)
            if 0 <= parsed <= 0xFFFFFF: return parsed
    except: pass
    return INV_COLOR

async def get_branding(ctx=None, guild=None, bot=None):
    target_guild = ctx.guild if ctx else guild
    target_bot = ctx.bot if ctx else bot
    
    bot_name = target_bot.user.name if target_bot and target_bot.user else "System"
    bot_icon = target_bot.user.display_avatar.url if target_bot and target_bot.user else None
    is_premium = False
    
    if target_guild:
        db_paths = ["db/premium.db", "premium.db", "../premium.db", "data/premium.db", "core/premium.db"]
        for path in db_paths:
            if os.path.exists(path):
                try:
                    async with aiosqlite.connect(path) as db:
                        async with db.execute("SELECT 1 FROM premium_guilds WHERE guild_id = ?", (target_guild.id,)) as cursor:
                            if await cursor.fetchone(): is_premium = True; break
                except: continue
                
    if is_premium and target_guild and target_guild.me:
        bot_name = target_guild.me.display_name
        bot_icon = target_guild.me.display_avatar.url
        
    return bot_name, safe_url(bot_icon), is_premium

def _hex_to_rgba(hex_str: str, alpha: int = 255):
    try:
        h = hex_str.lstrip("#")
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
        return (r, g, b, alpha)
    except: return (255, 255, 255, alpha)

def _make_leave_card(avatar_bytes: bytes, username: str, member_count: int, config: dict = None, bg_bytes: bytes = None) -> io.BytesIO:
    W, H = 1000, 340
    cfg = {**{"accent_color": "FFFFFF", "label": "Goodbye"}, **(config or {})}
    accent_hex = cfg.get("accent_color") or "FFFFFF"
    accent     = _hex_to_rgba(accent_hex, 255)
    accent_dim = _hex_to_rgba(accent_hex, 160)

    bg_src = Image.new("RGBA", (W, H), (30, 30, 35, 255))
    if cfg.get("bg_type") == "custom" and bg_bytes:
        try: bg_src = Image.open(io.BytesIO(bg_bytes)).convert("RGBA").resize((W, H), Image.LANCZOS)
        except: pass
    elif avatar_bytes:
        try: bg_src = Image.open(io.BytesIO(avatar_bytes)).convert("RGBA").resize((W, H), Image.LANCZOS)
        except: pass

    bg = bg_src.filter(ImageFilter.GaussianBlur(radius=28))
    dark = Image.new("RGBA", (W, H), (0, 0, 0, 155))
    bg = Image.alpha_composite(bg, dark)

    card = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    card_draw = ImageDraw.Draw(card)
    card_draw.rounded_rectangle([22, 22, W - 22, H - 22], radius=28, fill=(15, 15, 18, 210), outline=(_hex_to_rgba(accent_hex, 80)), width=2)
    img = Image.alpha_composite(bg, card)
    draw = ImageDraw.Draw(img)

    AV_CX, AV_CY, AV_R = 160, H // 2, 100
    for t, a in [(6, 30), (4, 80), (2, 170), (1, 255)]:
        draw.ellipse([AV_CX - AV_R - t, AV_CY - AV_R - t, AV_CX + AV_R + t, AV_CY + AV_R + t], outline=_hex_to_rgba(accent_hex, a), width=2)

    if avatar_bytes:
        try:
            av = Image.open(io.BytesIO(avatar_bytes)).convert("RGBA").resize((AV_R * 2, AV_R * 2), Image.LANCZOS)
            mask = Image.new("L", (AV_R * 2, AV_R * 2), 0)
            ImageDraw.Draw(mask).ellipse([0, 0, AV_R * 2, AV_R * 2], fill=255)
            av.putalpha(mask)
            img.paste(av, (AV_CX - AV_R, AV_CY - AV_R), av)
            draw = ImageDraw.Draw(img)
        except: pass

    TX = AV_CX + AV_R + 50
    try:
        f_label  = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 22)
        f_name   = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 62)
        f_badge  = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 17)
        f_footer = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 14)
    except:
        f_label = f_name = f_badge = f_footer = ImageFont.load_default()

    draw.text((TX, AV_CY - 92), cfg.get("label") or "Goodbye", font=f_label, fill=(200, 200, 210, 255))
    name = username if len(username) <= 18 else username[:16] + "…"
    draw.text((TX, AV_CY - 58), name, font=f_name, fill=(255, 255, 255, 255))

    try: name_w = int(draw.textlength(name, font=f_name))
    except: name_w = 200
    uy = AV_CY - 58 + 68
    draw.rounded_rectangle([TX, uy, TX + name_w, uy + 3], radius=2, fill=accent)

    badge_text = f"MEMBER #{member_count:,}"
    try: badge_w = int(draw.textlength(badge_text, font=f_badge)) + 28
    except: badge_w = 120
    draw.rounded_rectangle([TX, uy + 14, TX + badge_w, uy + 14 + 34], radius=17, fill=(0, 0, 0, 0), outline=accent_dim, width=2)
    draw.text((TX + 14, uy + 14 + 7), badge_text, font=f_badge, fill=(220, 220, 230, 255))

    if cfg.get("footer_text"):
        try: fw = int(draw.textlength(cfg["footer_text"], font=f_footer))
        except: fw = 100
        draw.text(((W - fw) // 2, H - 44), cfg["footer_text"], font=f_footer, fill=(160, 160, 170, 255))

    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return buf

async def _fetch_avatar(url: str) -> bytes | None:
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=5) as r:
                if r.status == 200: return await r.read()
    except: pass
    return None

def _simple_prompt(text: str, color: int = INV_COLOR) -> LayoutView:
    v = LayoutView(); c = Container(accent_color=color)
    c.add_item(TextDisplay(text))
    v.add_item(c)
    return v

def build_v2_card(e_info: dict, color: int = INV_COLOR, buttons: list = None, top_text: str = None) -> LayoutView:
    e_info = e_info or {}
    v = LayoutView()
    c = Container(accent_color=color if isinstance(color, int) else INV_COLOR)

    def _s(val):
        if val is None: return None
        val = str(val).strip()
        return val if val else None

    title       = _s(e_info.get("title"))
    desc        = _s(e_info.get("description"))
    author_name = _s(e_info.get("author_name"))
    footer_text = _s(e_info.get("footer_text"))
    thumb       = _s(e_info.get("thumbnail"))
    img         = _s(e_info.get("image"))
    top_text    = _s(top_text)

    has_content = False

    try:
        if top_text:
            c.add_item(TextDisplay(top_text))
            c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
            has_content = True

        if author_name:
            c.add_item(TextDisplay(f"-# {author_name}"))
            has_content = True

        body_parts = []
        if title: body_parts.append(f"**{title}**")
        if desc:  body_parts.append(desc)
        body_text = "\n".join(body_parts) if body_parts else None

        valid_thumb = thumb and thumb.startswith("http")
        if body_text:
            if valid_thumb: c.add_item(Section(TextDisplay(body_text), accessory=Thumbnail(thumb)))
            else: c.add_item(TextDisplay(body_text))
            has_content = True
        elif valid_thumb:
            c.add_item(Section(TextDisplay("\u200b"), accessory=Thumbnail(thumb)))
            has_content = True

        valid_img = img and img.startswith("http")
        if valid_img:
            if has_content: c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
            c.add_item(MediaGallery(discord.MediaGalleryItem(img)))
            has_content = True

        if footer_text:
            if has_content: c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
            c.add_item(TextDisplay(f"-# {footer_text}"))
            has_content = True

        if not has_content:
            c.add_item(TextDisplay(f"{E_DOT} | Layout is empty. Use the dropdown to add content."))

        if buttons:
            valid_buttons = []
            for b in buttons[:3]:
                try:
                    label = _s(b.get("label")) or "Link"
                    url   = _s(b.get("url"))
                    if url and url.startswith("http"):
                        valid_buttons.append(Button(label=label[:80], url=url, style=discord.ButtonStyle.link))
                except Exception: continue
            if valid_buttons:
                c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
                c.add_item(ActionRow(*valid_buttons))

    except Exception as e:
        c = Container(accent_color=INV_COLOR)
        c.add_item(TextDisplay(f"{E_WARN} | This layout has invalid data and could not render fully.\n-# Error: `{e}`"))

    v.add_item(c)
    return v


class LeaveHelpPagination(LayoutView):
    def __init__(self, ctx, bot_name: str):
        super().__init__(timeout=180)
        self.ctx = ctx
        self.bot_name = bot_name
        self.cmd_pfx = "leave"
        self.current_page = 1
        self.per_page = 6  
        
        self.cmds = [
            {"name": "leave create <name>", "desc": "Configure a new gleave setup."},
            {"name": "leave edit <name>", "desc": "Modify an existing setup via Layout Builder."},
            {"name": "leave delete <name>", "desc": "Delete a specific configuration."},
            {"name": "leave list", "desc": "List all your active setups."},
            {"name": "leave test <name>", "desc": "Send a test preview in the channel/DM."},
            {"name": "leave enable <name>", "desc": "Turn on a specific gleave message."},
            {"name": "leave disable <name>", "desc": "Turn off a specific gleave message."},
            {"name": "leave channel add <name> <#channel>", "desc": "Set target channel for a setup."},
            {"name": "leave channel reset <name>", "desc": "Remove the target channel."},
            {"name": "leave dm enable/disable <name>", "desc": "Toggle sending leave message in DMs."},
            {"name": "leave ping enable/disable <name>", "desc": "Toggle mentioning the user."},
            {"name": "leave autodelete enable <name> <time>", "desc": "Auto-delete after a set time."},
            {"name": "leave button add <name> <label> <url>", "desc": "Add a clickable URL button."},
            {"name": "leave button remove <name> <label>", "desc": "Remove a specific button."},
            {"name": "leave clone <server_id>", "desc": "[Premium] Clone setup from another server."},
        ]

        self.max_pages = max(1, (len(self.cmds) + self.per_page - 1) // self.per_page)
        
        self.b_first = Button(label="𝐅ɪʀꜱᴛ", style=discord.ButtonStyle.secondary, custom_id="w_first")
        self.b_prev = Button(label="𝐏ʀᴇᴠ", style=discord.ButtonStyle.secondary, custom_id="w_prev")
        self.b_next = Button(label="𝐍ᴇxᴛ", style=discord.ButtonStyle.secondary, custom_id="w_next")
        self.b_last = Button(label="𝐋ᴀꜱᴛ", style=discord.ButtonStyle.secondary, custom_id="w_last")
        self.b_del = Button(label="𝐂ʟᴏꜱᴇ", style=discord.ButtonStyle.danger, custom_id="w_del")

        self.b_first.callback = self.cb_first
        self.b_prev.callback = self.cb_prev
        self.b_next.callback = self.cb_next
        self.b_last.callback = self.cb_last
        self.b_del.callback = self.cb_del
        
        self._build_ui()

    def _build_ui(self):
        self.clear_items()
        start = (self.current_page - 1) * self.per_page
        end = start + self.per_page
        page_cmds = self.cmds[start:end]

        c = Container(accent_color=INV_COLOR)
        c.add_item(TextDisplay(f"## {self.bot_name} — Leave\n**{len(self.cmds)}** sub-commands available"))
        c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
        c.add_item(TextDisplay(f"{CB}yaml\n<..> <required> | [..] [optional]\n{CB}"))
        c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
        
        cmds_text = ""
        for cmd in page_cmds:
            cmds_text += f"`{cmd['name']}`\n> <:RightArrow:1511137811418448006> {cmd['desc']}\n\n"
            
        c.add_item(TextDisplay(cmds_text.strip()))
        c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
        c.add_item(TextDisplay(f"-# Page {self.current_page}/{self.max_pages} | Requested by **{self.ctx.author.display_name}**"))
        c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))

        self.b_first.disabled = (self.current_page == 1)
        self.b_prev.disabled = (self.current_page == 1)
        self.b_next.disabled = (self.current_page == self.max_pages)
        self.b_last.disabled = (self.current_page == self.max_pages)

        c.add_item(ActionRow(self.b_first, self.b_prev, self.b_next, self.b_last, self.b_del))
        self.add_item(c)

    async def _update_view(self, i):
        if i.user != self.ctx.author: return await i.response.defer()
        self._build_ui()
        await i.response.edit_message(view=self)

    async def cb_first(self, i): self.current_page = 1; await self._update_view(i)
    async def cb_prev(self, i): self.current_page -= 1; await self._update_view(i)
    async def cb_next(self, i): self.current_page += 1; await self._update_view(i)
    async def cb_last(self, i): self.current_page = self.max_pages; await self._update_view(i)
    async def cb_del(self, i): 
        if i.user == self.ctx.author: 
            try: await i.message.delete()
            except discord.NotFound: pass
        else: await i.response.defer()


class SetupModeSelector(LayoutView):
    def __init__(self, cog, ctx, bot_name, name=""):
        super().__init__(timeout=120)
        self.cog = cog
        self.ctx = ctx
        self.bot_name = bot_name
        self.setup_name = name

        self.b1 = Button(label="Message Mode", style=discord.ButtonStyle.secondary)
        self.b2 = Button(label="Embed Mode", style=discord.ButtonStyle.secondary)
        self.b3 = Button(label="Image Mode", style=discord.ButtonStyle.secondary)
        self.b_del = Button(label="𝐂ʟᴏꜱᴇ", style=discord.ButtonStyle.danger)

        self.b1.callback = self.msg_btn
        self.b2.callback = self.emb_btn
        self.b3.callback = self.img_btn
        self.b_del.callback = self.cb_del

        self._build_ui()

    def _build_ui(self):
        c = Container(accent_color=INV_COLOR)
        name_str = f" — {self.setup_name}" if self.setup_name else ""
        c.add_item(TextDisplay(f"**New Leave Setup{name_str}**\nChoose a **leave mode** for this setup:"))
        c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
        modes = (
            "`Message Mode`\n> <:RightArrow:1511137811418448006> Simple text-only goodbye.\n\n"
            "`Embed Mode`\n> <:RightArrow:1511137811418448006> Standard Embeds with full Image & Rich support.\n\n"
            "`Image Mode`\n> <:RightArrow:1511137811418448006> Eye-catching goodbye card with avatar."
        )
        c.add_item(TextDisplay(modes))
        c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
        c.add_item(ActionRow(self.b1, self.b2, self.b3, self.b_del))
        self.add_item(c)

    async def msg_btn(self, i: discord.Interaction):
        if i.user != self.ctx.author: return await i.response.defer()
        try: await i.message.delete()
        except: pass
        await self.cog._run_simple_setup(self.ctx, self.setup_name)

    async def emb_btn(self, i: discord.Interaction):
        if i.user != self.ctx.author: return await i.response.defer()
        try: await i.message.delete()
        except: pass
        await self.cog._run_embed_setup(self.ctx, self.setup_name)

    async def img_btn(self, i: discord.Interaction):
        if i.user != self.ctx.author: return await i.response.defer()
        try: await i.message.delete()
        except: pass
        if not await self.cog._is_premium(self.ctx.guild.id):
            return await self.cog.send_error_v2(self.ctx, "**Image Mode is a Premium Feature.**", show_usage=False)
        await self.cog._run_image_setup(self.ctx, self.setup_name)

    async def cb_del(self, i: discord.Interaction): 
        if i.user == self.ctx.author:
            try: await i.message.delete()
            except: pass
        else: await i.response.defer()


class ImageCardBuilderView(LayoutView):
    def __init__(self, cog, ctx, setup_name, existing_cfg=None):
        super().__init__(timeout=600)
        self.cog = cog
        self.ctx = ctx
        self.setup_name = setup_name
        self.layout_idx = 1
        self.layouts = ["FFFFFF", "FF6400", "00FFCC", "FF00FF"]
        
        default_cfg = {
            "message": None, "label": "Goodbye",
            "bg_type": "avatar", "accent_color": "FFFFFF",
            "footer_text": None, "custom_bg_url": None
        }
        self.cfg = {**default_cfg, **(existing_cfg or {})}
        
        try: self.layout_idx = self.layouts.index(self.cfg["accent_color"]) + 1
        except: self.layout_idx = 1
        
        self.b_back = Button(label="Back", style=discord.ButtonStyle.primary)
        self.b_next = Button(label="Next", style=discord.ButtonStyle.primary)
        self.b_content = Button(label="Set Content", style=discord.ButtonStyle.secondary)
        self.b_text = Button(label="Set Card Text", style=discord.ButtonStyle.secondary)
        self.b_bg = Button(label="Set Background", style=discord.ButtonStyle.secondary)
        self.b_prev = Button(label="Preview Card", style=discord.ButtonStyle.secondary)
        self.b_save = Button(label="Confirm & Save", style=discord.ButtonStyle.success)
        self.b_cancel = Button(label="Cancel", style=discord.ButtonStyle.danger)
        
        self.b_back.callback = self.btn_back
        self.b_next.callback = self.btn_next
        self.b_content.callback = self.btn_content
        self.b_text.callback = self.btn_text
        self.b_bg.callback = self.btn_bg
        self.b_prev.callback = self.btn_preview
        self.b_save.callback = self.btn_save
        self.b_cancel.callback = self.btn_cancel
        
        self._build_ui()

    def _build_ui(self):
        self.clear_items()
        bg_status = "Custom Image" if self.cfg["bg_type"] == "custom" else "User Avatar"
        text = (
            f"** Image Card Builder [{self.setup_name}]**\n"
            f"◉ **Selected Layout:** {self.layout_idx} of 4\n"
            f"◉ **Background:** {bg_status}\n\n"
            "> <:RightArrow:1511137811418448006> Use **Back / Next** to browse layouts.\n"
            "> <:RightArrow:1511137811418448006> Use **Set Background** to upload your own Image!\n"
            "> <:RightArrow:1511137811418448006> Click **Preview Card** to test it out."
        )
        c = Container(accent_color=INV_COLOR)
        c.add_item(TextDisplay(text))
        c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
        c.add_item(ActionRow(self.b_back, self.b_next, self.b_content, self.b_text, self.b_bg))
        c.add_item(ActionRow(self.b_prev, self.b_save, self.b_cancel))
        self.add_item(c)

    async def btn_back(self, i: discord.Interaction):
        if i.user != self.ctx.author: return await i.response.defer()
        self.layout_idx = self.layout_idx - 1 if self.layout_idx > 1 else 4
        self.cfg["accent_color"] = self.layouts[self.layout_idx - 1]
        self._build_ui()
        await i.response.edit_message(view=self)

    async def btn_next(self, i: discord.Interaction):
        if i.user != self.ctx.author: return await i.response.defer()
        self.layout_idx = self.layout_idx + 1 if self.layout_idx < 4 else 1
        self.cfg["accent_color"] = self.layouts[self.layout_idx - 1]
        self._build_ui()
        await i.response.edit_message(view=self)

    async def btn_content(self, i: discord.Interaction):
        if i.user != self.ctx.author: return await i.response.defer()
        await i.response.send_message(view=_simple_prompt("Enter message text above the image (type `none` to remove):"), ephemeral=True)
        try:
            msg = await self.ctx.bot.wait_for("message", timeout=60, check=lambda m: m.author == self.ctx.author and m.channel == self.ctx.channel)
            self.cfg["message"] = None if msg.content.lower() == "none" else msg.content
            await msg.delete()
        except: pass

    async def btn_text(self, i: discord.Interaction):
        if i.user != self.ctx.author: return await i.response.defer()
        await i.response.send_message(view=_simple_prompt("Enter new label text (e.g. `Goodbye!`):"), ephemeral=True)
        try:
            msg = await self.ctx.bot.wait_for("message", timeout=60, check=lambda m: m.author == self.ctx.author and m.channel == self.ctx.channel)
            self.cfg["label"] = msg.content
            await msg.delete()
        except: pass

    async def btn_bg(self, i: discord.Interaction):
        if i.user != self.ctx.author: return await i.response.defer()
        await i.response.send_message(view=_simple_prompt("Send an Image URL or **Upload an Image** here (type `avatar` to use profile picture):"), ephemeral=True)
        try:
            msg = await self.ctx.bot.wait_for("message", timeout=120, check=lambda m: m.author == self.ctx.author and m.channel == self.ctx.channel)
            val = msg.content.strip()
            if msg.attachments: val = msg.attachments[0].url
                
            if val.lower() in ['none', 'avatar']:
                self.cfg["bg_type"], self.cfg["custom_bg_url"] = "avatar", None
                await i.followup.send(view=_simple_prompt(f"{E_TICK} Background reset to **User Avatar**."), ephemeral=True)
            elif val.startswith("http"):
                self.cfg["bg_type"], self.cfg["custom_bg_url"] = "custom", val
                await i.followup.send(view=_simple_prompt(f"{E_TICK} **Custom Background** successfully saved!"), ephemeral=True)
            else:
                await self.cog.send_error_v2(self.ctx, "**Invalid Image URL.** Upload a picture or link.", show_usage=False)
                
            await msg.delete()
            self._build_ui(); await self.message.edit(view=self)
        except: pass

    async def btn_preview(self, i: discord.Interaction):
        if i.user != self.ctx.author: return await i.response.defer()
        await i.response.defer(ephemeral=True)
        avatar_bytes = await _fetch_avatar(self.ctx.author.avatar.url if self.ctx.author.avatar else self.ctx.author.default_avatar.url)
        bg_bytes = await _fetch_avatar(self.cfg["custom_bg_url"]) if self.cfg.get("bg_type") == "custom" and self.cfg.get("custom_bg_url") else None
        buf = await self.cog.bot.loop.run_in_executor(None, _make_leave_card, avatar_bytes or b"", self.ctx.author.name, self.ctx.guild.member_count, self.cfg, bg_bytes)
        await i.followup.send(content="**Card Preview:**", file=discord.File(buf, filename="preview.png"), ephemeral=True)

    async def btn_save(self, i: discord.Interaction):
        if i.user != self.ctx.author: return await i.response.defer()
        await self.cog._save_data(self.ctx.guild.id, self.setup_name, "image", self.cfg["message"], self.cfg)
        await i.response.edit_message(view=_simple_prompt(f"{E_TICK} **Image Card configured!** Use `gleave channel add {self.setup_name} <#channel>`."))

    async def btn_cancel(self, i: discord.Interaction):
        if i.user != self.ctx.author: return await i.response.defer()
        try: await i.message.delete()
        except: pass


class EmbedBuilderView(LayoutView):
    def __init__(self, cog, ctx, setup_name, existing_data=None):
        super().__init__(timeout=600)
        self.cog = cog; self.ctx = ctx; self.setup_name = setup_name; self.message = None
        default_data = {
            "message": None, "title": "Goodbye", "description": "Edit this description...",
            "color": None, "footer_text": None, "footer_icon": None,
            "author_name": None, "author_icon": None, "thumbnail": None, "image": None
        }
        self.e_data = {**default_data, **(existing_data or {})}
        self.sel = Select(
            placeholder="Select a component to edit…",
            options=[
                discord.SelectOption(label="Message Content", value="`message`"),
                discord.SelectOption(label="Title", value="title"),
                discord.SelectOption(label="Description", value="description"),
                discord.SelectOption(label="Color", value="color"),
                discord.SelectOption(label="Thumbnail", value="thumbnail"),
                discord.SelectOption(label="Image URL", value="image"),
                discord.SelectOption(label="Author Name", value="author_name"),
                discord.SelectOption(label="Author Icon", value="author_icon"),
                discord.SelectOption(label="Footer Text", value="footer_text"),
                discord.SelectOption(label="Footer Icon", value="footer_icon"),
            ]
        )
        self.sel.callback = self.select_cb
        self.b_save = Button(label="✅ Save", style=discord.ButtonStyle.success)
        self.b_cancel = Button(label="❌ Cancel", style=discord.ButtonStyle.danger)
        self.b_save.callback = self.btn_save
        self.b_cancel.callback = self.btn_cancel
        self._build_ui()

    def _rendered_data(self) -> dict:
        return {
            "title":       self.cog.safe_format(self.e_data.get("title"), self.ctx.author, self.ctx.guild),
            "description": self.cog.safe_format(self.e_data.get("description"), self.ctx.author, self.ctx.guild),
            "footer_text": self.cog.safe_format(self.e_data.get("footer_text"), self.ctx.author, self.ctx.guild),
            "footer_icon": self.cog.safe_format(self.e_data.get("footer_icon"), self.ctx.author, self.ctx.guild),
            "author_name": self.cog.safe_format(self.e_data.get("author_name"), self.ctx.author, self.ctx.guild),
            "author_icon": self.cog.safe_format(self.e_data.get("author_icon"), self.ctx.author, self.ctx.guild),
            "thumbnail":   self.cog.safe_format(self.e_data.get("thumbnail"), self.ctx.author, self.ctx.guild),
            "image":       self.cog.safe_format(self.e_data.get("image"), self.ctx.author, self.ctx.guild),
        }

    def _build_ui(self):
        self.clear_items()
        c = Container(accent_color=get_safe_color(self.e_data.get("color")))
        c.add_item(TextDisplay(f"**📝 Embed Builder [{self.setup_name}]**"))
        c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))

        content = self.cog.safe_format(self.e_data.get("message`l"), self.ctx.author, self.ctx.guild)
        if content:
            c.add_item(TextDisplay(f"-# Message: {content}"))
            c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))

        rendered = self._rendered_data()
        title, desc = rendered.get("title"), rendered.get("description")
        thumb = (rendered.get("thumbnail") or "").strip()
        img   = (rendered.get("image") or "").strip()

        if rendered.get("author_name"): c.add_item(TextDisplay(f"-# {rendered['author_name']}"))

        body_parts = []
        if title: body_parts.append(f"**{title}**")
        if desc:  body_parts.append(desc)
        body_text = "\n".join(body_parts) if body_parts else "*Embed is empty — use the dropdown below to add content.*"

        if thumb.startswith("http"): c.add_item(Section(TextDisplay(body_text), accessory=Thumbnail(thumb)))
        else: c.add_item(TextDisplay(body_text))

        if img.startswith("http"):
            c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
            c.add_item(MediaGallery(discord.MediaGalleryItem(img)))

        if rendered.get("footer_text"):
            c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
            c.add_item(TextDisplay(f"-# {rendered['footer_text']}"))

        c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
        c.add_item(TextDisplay("<:RightArrow:1511137811418448006> | Use the **dropdown** to edit a part. Changes live-update above."))
        c.add_item(ActionRow(self.sel))
        c.add_item(ActionRow(self.b_save, self.b_cancel))
        self.add_item(c)

    async def select_cb(self, i: discord.Interaction):
        if i.user != self.ctx.author: return await i.response.defer()
        val = self.sel.values[0]
        await i.response.send_message(view=_simple_prompt(f"Enter a value for **{val}** (or type/upload `none` to clear):"), ephemeral=True)
        try:
            msg = await self.ctx.bot.wait_for("message", timeout=120, check=lambda m: m.author == self.ctx.author and m.channel == self.ctx.channel)
            content = msg.content.strip()
            if msg.attachments: content = msg.attachments[0].url
            if content.lower() == "none": content = None

            if val == "color" and content:
                try:
                    parsed = int(content.lstrip("#"), 16)
                    if not (0 <= parsed <= 0xFFFFFF): raise ValueError
                    content = f"#{parsed:06x}"
                except:
                    try: await msg.delete()
                    except: pass
                    return await i.followup.send(view=_simple_prompt(f"{E_CROSS} | Invalid hex color.", ERROR_COLOR), ephemeral=True)

            self.e_data[val] = content
            try: await msg.delete()
            except: pass
            self._build_ui(); await self.message.edit(view=self)
        except: pass

    async def btn_save(self, i: discord.Interaction):
        if i.user != self.ctx.author: return await i.response.defer()
        await self.cog._save_data(self.ctx.guild.id, self.setup_name, "embed", self.e_data.get("message") or "", self.e_data)
        await i.response.edit_message(view=_simple_prompt(f"{E_TICK} | **Layout saved successfully!** Use `gleave channel add {self.setup_name} <#channel>`.", SUCCESS_COLOR))
    async def btn_cancel(self, i: discord.Interaction):
        if i.user != self.ctx.author: return await i.response.defer()
        try: await i.message.delete()
        except: pass


class LeaveSystem(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self._create_tables())
        if not hasattr(self.bot, "_multi_welcome_cache"): self.bot._multi_welcome_cache = set()
        self._event_cache = self.bot._multi_welcome_cache

    async def _create_tables(self):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("""
            CREATE TABLE IF NOT EXISTS multi_leave (
                guild_id INTEGER, name TEXT, w_type TEXT, w_msg TEXT,
                channel_id INTEGER, embed_data TEXT, autodel INTEGER, 
                enabled INTEGER DEFAULT 1, dm_greet INTEGER DEFAULT 0, mention_user INTEGER DEFAULT 0,
                buttons TEXT, PRIMARY KEY (guild_id, name)
            )""")
            try: await db.execute("ALTER TABLE multi_leave ADD COLUMN buttons TEXT")
            except: pass
            await db.commit()

    async def _is_premium(self, guild_id: int) -> bool:
        db_paths = ["db/premium.db", "premium.db", "../premium.db", "data/premium.db", "core/premium.db"]
        for path in db_paths:
            if os.path.exists(path):
                try:
                    async with aiosqlite.connect(path) as db:
                        async with db.execute("SELECT 1 FROM premium_guilds WHERE guild_id = ?", (guild_id,)) as cursor:
                            if await cursor.fetchone(): return True
                except: continue
        return False

    def safe_format(self, text, member, guild):
        if not text: return text
        def get_ordinal(n): return "%d%s" % (n, "tsnrhtdd"[(n//10%10!=1)*(n%10<4)*n%10::4])

        now = datetime.now()
        placeholders = {
            "user": member.mention, "user_name": member.name, "user_id": str(member.id),
            "user_nick": member.display_name, "user_avatar": member.avatar.url if member.avatar else member.default_avatar.url,
            "server_name": guild.name, "server_id": str(guild.id), 
            "server_membercount": str(guild.member_count),
            "server_membercount_ord": get_ordinal(guild.member_count),
            "server_icon": guild.icon.url if guild.icon else "",
            "server_owner": f"<@{guild.owner_id}>",
            "time": now.strftime("%I:%M %p"), "date": now.strftime("%b %d, %Y"), "timestamp": f"<t:{int(now.timestamp())}:R>"
        }
        return re.sub(r"\{(\w+)\}", lambda m: str(placeholders.get(m.group(1).lower(), f"{{{m.group(1)}}} ")), text)

    async def get_config(self, guild_id, name):
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT * FROM multi_leave WHERE guild_id = ? AND name = ?", (guild_id, name)) as cur: return await cur.fetchone()

    async def get_all_active_configs(self, guild_id):
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT * FROM multi_leave WHERE guild_id = ? AND enabled = 1", (guild_id,)) as cur: return await cur.fetchall()

    def _block_global_error(self, ctx):
        setattr(ctx, 'handled', True)
        if hasattr(ctx, 'command') and ctx.command:
            try: setattr(ctx.command, 'on_error', None)
            except: pass

    async def send_v2(self, ctx, text: str, color=INV_COLOR):
        self._block_global_error(ctx)
        v = LayoutView(); c = Container(accent_color=color); c.add_item(TextDisplay(text)); v.add_item(c)
        if hasattr(ctx, "reply"): return await ctx.reply(view=v, mention_author=False)
        else: return await ctx.send(view=v)

    async def send_error_v2(self, ctx, msg="You are missing one or more\nrequired parameters!", show_usage=False):
        self._block_global_error(ctx)
        bot_name, _, _ = await get_branding(ctx)
        v = LayoutView(); c = Container(accent_color=ERROR_COLOR)
        c.add_item(TextDisplay(f"**###  {E_CROSS} {bot_name} Missing Argument !**"))
        c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
        c.add_item(TextDisplay(msg))
        if show_usage: c.add_item(TextDisplay(f"> <:RightArrow:1511137811418448006> **Correct Usage ~**\n{CB}\n{ctx.prefix}{ctx.command.qualified_name} {ctx.command.usage}\n{CB}"))
        v.add_item(c); await ctx.send(view=v)

    async def send_subcommand_help(self, ctx, group_name: str, cmds: list):
        self._block_global_error(ctx)
        bot_name, _, _ = await get_branding(ctx)
        v = LayoutView(); c = Container(accent_color=INV_COLOR)
        c.add_item(TextDisplay(f"## {bot_name} — {group_name.capitalize()}\n**{len(cmds)}** sub-commands available"))
        c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
        
        cmds_text = ""
        for cmd in cmds: cmds_text += f"`{cmd['name']}`\n> <:RightArrow:1511137811418448006> {cmd['desc']}\n\n"
        c.add_item(TextDisplay(cmds_text.strip()))
        c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
        
        b_del = Button(label="𝐂ʟᴏ𝐒ᴇ", style=discord.ButtonStyle.danger)
        async def cb_del(i: discord.Interaction):
            if i.user == ctx.author:
                try: await i.message.delete()
                except: pass
            else: await i.response.defer()
        b_del.callback = cb_del
        c.add_item(ActionRow(b_del)); v.add_item(c)
        if hasattr(ctx, "reply"): await ctx.reply(view=v, mention_author=False)
        else: await ctx.send(view=v)

    @commands.hybrid_group(invoke_without_command=True, name="gleave", aliases=["goodbye"])
    @commands.has_permissions(administrator=True)
    async def leave(self, ctx: commands.Context):
        self._block_global_error(ctx)
        if ctx.invoked_subcommand is None:
            if ctx.subcommand_passed: return await self.send_error_v2(ctx, f"Invalid command: `{ctx.subcommand_passed}`")
            bot_name, _, _ = await get_branding(ctx)
            await ctx.send(view=LeaveHelpPagination(ctx, bot_name))

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        await self._trigger_event(member)

    async def _trigger_event(self, member, is_test=False, test_name=None, test_channel=None) -> bool:
        configs = await self.get_all_active_configs(member.guild.id)
        if is_test and test_name: configs = [c for c in configs if c[1] == test_name]
        if not configs: return False
        
        success = False
        for config in configs:
            g_id, c_name, w_type, w_msg, ch_id, e_data, autodel, enabled, dm_greet, mention_user, buttons_str = config
            
            cache_key = f"{member.id}_{g_id}_{c_name}_leave_{is_test}"
            if cache_key in self._event_cache: continue 
            self._event_cache.add(cache_key)
            self.bot.loop.call_later(5.0, lambda k=cache_key: self._event_cache.discard(k) if k in self._event_cache else None)

            target = self.bot.get_channel(ch_id) if not dm_greet else member
            if is_test and not target and not dm_greet: target = test_channel
            if not target and not dm_greet: continue

            ping_str = f"{member.mention} " if mention_user and not dm_greet else ""
            has_buttons = False
            try:
                btns = json.loads(buttons_str) if buttons_str else []
                if btns: has_buttons = True
            except: pass

            try:
                if w_type == "simple" and w_msg:
                    content_txt = self.safe_format(w_msg, member, member.guild)
                    if ping_str and member.mention not in content_txt: content_txt = ping_str + content_txt
                    
                    v = discord.ui.View() if has_buttons else None
                    if has_buttons:
                        for b in btns: v.add_item(discord.ui.Button(label=b['label'], url=b['url']))
                    
                    msg = await target.send(content=content_txt, view=v)
                    if autodel and msg and not dm_greet: await msg.delete(delay=autodel)

                elif w_type == "embed" and e_data:
                    try: e_info = json.loads(e_data)
                    except: continue

                    content_txt = self.safe_format(e_info.get("message", ""), member, member.guild) or ""
                    if ping_str and member.mention not in content_txt: content_txt = ping_str + content_txt

                    rendered = {
                        "title":       self.safe_format(e_info.get("title"), member, member.guild),
                        "description":self.safe_format(e_info.get("description"), member, member.guild),
                        "footer_text":self.safe_format(e_info.get("footer_text"), member, member.guild),
                        "footer_icon":self.safe_format(e_info.get("footer_icon", ""), member, member.guild),
                        "author_name":self.safe_format(e_info.get("author_name"), member, member.guild),
                        "author_icon":self.safe_format(e_info.get("author_icon", ""), member, member.guild),
                        "thumbnail":  self.safe_format(e_info.get("thumbnail", ""), member, member.guild),
                        "image":      self.safe_format(e_info.get("image", ""), member, member.guild),
                    }
                    if not any(rendered.values()): rendered["description"] = "Goodbye!"
                    
                    layout_view = build_v2_card(rendered, get_safe_color(e_info.get("color")), btns if has_buttons else None, top_text=content_txt or None)
                    msg = await target.send(view=layout_view)
                    if autodel and msg and not dm_greet: await msg.delete(delay=autodel)

                elif w_type == "image":
                    avatar_bytes = await _fetch_avatar(member.avatar.url if member.avatar else member.default_avatar.url)
                    try: img_cfg = json.loads(e_data) if e_data else {}
                    except: img_cfg = {}
                    
                    bg_bytes = await _fetch_avatar(img_cfg["custom_bg_url"]) if img_cfg.get("bg_type") == "custom" and img_cfg.get("custom_bg_url") else None
                    if img_cfg.get("label"): img_cfg["label"] = self.safe_format(img_cfg["label"], member, member.guild)
                    if img_cfg.get("footer_text"): img_cfg["footer_text"] = self.safe_format(img_cfg["footer_text"], member, member.guild)
                    
                    buf = await self.bot.loop.run_in_executor(None, _make_leave_card, avatar_bytes or b"", member.name, member.guild.member_count, img_cfg, bg_bytes)
                    file = discord.File(buf, filename="goodbye.png")
                    
                    content_txt = self.safe_format(img_cfg.get("message") or "", member, member.guild) or ""
                    if ping_str and member.mention not in content_txt: content_txt = ping_str + content_txt
                    
                    v = discord.ui.View() if has_buttons else None
                    if has_buttons:
                        for b in btns: v.add_item(discord.ui.Button(label=b['label'], url=b['url']))
                    
                    msg = await target.send(content=content_txt or None, file=file, view=v)
                    if autodel and msg and not dm_greet: await msg.delete(delay=autodel)
                success = True
            except Exception as e:
                print(f"[LeaveSystem] _trigger_event failed for config '{c_name}': {e}")
        return success

    @leave.command(name="create", aliases=["addsetup", "new"], usage="<name>")
    @commands.has_permissions(administrator=True)
    async def leave_create(self, ctx, *, name: str = None): 
        self._block_global_error(ctx)
        if not name: return await self.send_error_v2(ctx, show_usage=True)
        if await self.get_config(ctx.guild.id, name): return await self.send_error_v2(ctx, f"Setup `{name}` already exists. Use `gleave edit {name}` to modify.")
        bot_name, _, _ = await get_branding(ctx)
        await ctx.send(view=SetupModeSelector(self, ctx, bot_name, name))

    @leave.command(name="delete", aliases=["del", "remove"], usage="<name>")
    @commands.has_permissions(administrator=True)
    async def leave_delete(self, ctx, *, name: str = None):
        self._block_global_error(ctx)
        if not name: return await self.send_error_v2(ctx, show_usage=True)
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("DELETE FROM multi_leave WHERE guild_id = ? AND name = ?", (ctx.guild.id, name))
            await db.commit()
        await self.send_v2(ctx, f"{E_TICK} Setup `{name}` completely deleted.")

    async def _handle_toggle(self, ctx, name, enable):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("UPDATE multi_leave SET enabled = ? WHERE guild_id = ? AND name = ?", (1 if enable else 0, ctx.guild.id, name))
            await db.commit()
        status = "enabled" if enable else "disabled"
        await self.send_v2(ctx, f"{E_TICK} Setup `{name}` has been {status}.")

    @leave.command(name="enable", usage="<name>")
    @commands.has_permissions(administrator=True)
    async def leave_enable(self, ctx, *, name: str = None): 
        self._block_global_error(ctx)
        if not name: return await self.send_error_v2(ctx, show_usage=True)
        await self._handle_toggle(ctx, name, True)

    @leave.command(name="disable", usage="<name>")
    @commands.has_permissions(administrator=True)
    async def leave_disable(self, ctx, *, name: str = None): 
        self._block_global_error(ctx)
        if not name: return await self.send_error_v2(ctx, show_usage=True)
        await self._handle_toggle(ctx, name, False)

    @leave.group(name="channel", aliases=["ch", "chan"], invoke_without_command=True)
    @commands.has_permissions(administrator=True)
    async def leave_channel(self, ctx):
        self._block_global_error(ctx)
        if ctx.invoked_subcommand is None:
            if ctx.subcommand_passed: return await self.send_error_v2(ctx, f"Invalid command: `{ctx.subcommand_passed}`")
            cmds = [
                {"name": f"{ctx.prefix}gleave channel add <name> <#channel>", "desc": "Set the target channel for a specific setup."},
                {"name": f"{ctx.prefix}gleave channel reset <name>", "desc": "Remove the target channel from a setup."}
            ]
            await self.send_subcommand_help(ctx, "Leave Channel", cmds)

    @leave_channel.command(name="add", usage="<name> <#channel>")
    @commands.has_permissions(administrator=True)
    async def leave_channel_add(self, ctx, name: str = None, channel: discord.TextChannel = None): 
        self._block_global_error(ctx)
        if not name or not channel: return await self.send_error_v2(ctx, show_usage=True)
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("UPDATE multi_leave SET channel_id = ? WHERE guild_id = ? AND name = ?", (channel.id, ctx.guild.id, name))
            await db.commit()
        await self.send_v2(ctx, f"{E_TICK} Channel for `{name}` set to {channel.mention}")

    @leave_channel.command(name="reset", usage="<name>")
    @commands.has_permissions(administrator=True)
    async def leave_channel_reset(self, ctx, *, name: str = None): 
        self._block_global_error(ctx)
        if not name: return await self.send_error_v2(ctx, show_usage=True)
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("UPDATE multi_leave SET channel_id = NULL WHERE guild_id = ? AND name = ?", (ctx.guild.id, name))
            await db.commit()
        await self.send_v2(ctx, f"{E_TICK} Channel for `{name}` reset.")

    @leave.command(name="edit", usage="<name>")
    @commands.has_permissions(administrator=True)
    async def leave_edit(self, ctx, *, name: str = None):
        self._block_global_error(ctx)
        if not name: return await self.send_error_v2(ctx, show_usage=True)
        config = await self.get_config(ctx.guild.id, name)
        if not config: return await self.send_error_v2(ctx, f"Setup `{name}` not found!")
        w_type, w_msg, e_data = config[2], config[3], config[5]
        parsed_data = json.loads(e_data) if e_data else None
        if w_type == "simple": await self._run_simple_setup(ctx, name, w_msg)
        elif w_type == "embed": await self._run_embed_setup(ctx, name, parsed_data)
        elif w_type == "image": await self._run_image_setup(ctx, name, parsed_data)

    @leave.group(name="button", aliases=["btn"], invoke_without_command=True)
    @commands.has_permissions(administrator=True)
    async def leave_btn(self, ctx):
        self._block_global_error(ctx)
        if ctx.invoked_subcommand is None:
            if ctx.subcommand_passed: return await self.send_error_v2(ctx, f"Invalid command: `{ctx.subcommand_passed}`")
            cmds = [
                {"name": f"{ctx.prefix}gleave button add <name> <label> <url>", "desc": "Add a clickable URL button to a setup."},
                {"name": f"{ctx.prefix}gleave button remove <name> <label>", "desc": "Remove a specific button from a setup."}
            ]
            await self.send_subcommand_help(ctx, "Leave Button", cmds)

    @leave_btn.command(name="add", usage="<name> <label> <url>")
    @commands.has_permissions(administrator=True)
    async def leave_btn_add(self, ctx, name: str = None, label: str = None, url: str = None):
        self._block_global_error(ctx)
        if not name or not label or not url: return await self.send_error_v2(ctx, show_usage=True)
        if not url.startswith("http"): return await self.send_error_v2(ctx, "URL must start with http:// or https://")
        cfg = await self.get_config(ctx.guild.id, name)
        if not cfg: return await self.send_error_v2(ctx, f"Setup `{name}` not found.")
        
        btns = json.loads(cfg[10]) if cfg[10] else []
        if len(btns) >= 3: return await self.send_error_v2(ctx, "You can only have up to 3 buttons.")
        btns.append({"label": label, "url": url})
        
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("UPDATE multi_leave SET buttons = ? WHERE guild_id = ? AND name = ?", (json.dumps(btns), ctx.guild.id, name))
            await db.commit()
        await self.send_v2(ctx, f"{E_TICK} Button `{label}` added to `{name}`.")

    @leave_btn.command(name="remove", usage="<name> <label>")
    @commands.has_permissions(administrator=True)
    async def leave_btn_remove(self, ctx, name: str = None, label: str = None):
        self._block_global_error(ctx)
        if not name or not label: return await self.send_error_v2(ctx, show_usage=True)
        cfg = await self.get_config(ctx.guild.id, name)
        if not cfg: return await self.send_error_v2(ctx, f"Setup `{name}` not found.")
        
        btns = json.loads(cfg[10]) if cfg[10] else []
        new_btns = [b for b in btns if b['label'].lower() != label.lower()]
        
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("UPDATE multi_leave SET buttons = ? WHERE guild_id = ? AND name = ?", (json.dumps(new_btns), ctx.guild.id, name))
            await db.commit()
        await self.send_v2(ctx, f"{E_TICK} Button `{label}` removed from `{name}`.")

    @leave.command(name="list", aliases=["config", "setups"])
    @commands.has_permissions(administrator=True)
    async def leave_list(self, ctx):
        self._block_global_error(ctx)
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT name, enabled, channel_id, w_type FROM multi_leave WHERE guild_id = ?", (ctx.guild.id,)) as cur:
                rows = await cur.fetchall()
        if not rows: return await self.send_error_v2(ctx, "No Leave setups found.")
        txt = f"**📋 Leave Configuration Overview**\n\n"
        for name, enabled, ch_id, w_type in rows:
            status = "🟢" if enabled else "🔴"
            target = f"<#{ch_id}>" if ch_id else "DM/Not Set"
            txt += f"**{name}**\n> <:RightArrow:1511137811418448006> `{status}` | Type: `{w_type}` | Target: {target}\n\n"
        await self.send_v2(ctx, txt.strip())

    @leave.command(name="test", usage="<name>")
    @commands.has_permissions(administrator=True)
    async def leave_test(self, ctx, *, name: str = None):
        self._block_global_error(ctx)
        if not name: return await self.send_error_v2(ctx, show_usage=True)
        cfg = await self.get_config(ctx.guild.id, name)
        if not cfg: return await self.send_error_v2(ctx, f"Setup `{name}` not found!")
        
        success = await self._trigger_event(ctx.author, True, name, test_channel=ctx.channel)
        if success: await self.send_v2(ctx, f"{E_TICK} **Test successfully executed.**")
        else: await self.send_error_v2(ctx, "Failed to send. Check channel and permissions.")

    async def _toggle_bool(self, ctx, name, col, val):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(f"UPDATE multi_leave SET {col} = ? WHERE guild_id = ? AND name = ?", (val, ctx.guild.id, name))
            await db.commit()
        await self.send_v2(ctx, f"{E_TICK} `{col}` for `{name}` has been **{'Enabled' if val else 'Disabled'}**")

    @leave.group(name="dm", invoke_without_command=True)
    @commands.has_permissions(administrator=True)
    async def leave_dm(self, ctx):
        self._block_global_error(ctx)
        if ctx.invoked_subcommand is None:
            if ctx.subcommand_passed: return await self.send_error_v2(ctx, f"Invalid command: `{ctx.subcommand_passed}`")
            cmds = [
                {"name": f"{ctx.prefix}gleave dm enable <name>", "desc": "Send the leave message in Direct Messages."},
                {"name": f"{ctx.prefix}gleave dm disable <name>", "desc": "Disable DM leave messages."}
            ]
            await self.send_subcommand_help(ctx, "Leave DM", cmds)

    @leave_dm.command(name="enable", usage="<name>")
    @commands.has_permissions(administrator=True)
    async def leave_dm_en(self, ctx, *, name: str = None): 
        self._block_global_error(ctx)
        if not name: return await self.send_error_v2(ctx, show_usage=True)
        await self._toggle_bool(ctx, name, "dm_greet", 1)
        
    @leave_dm.command(name="disable", usage="<name>")
    @commands.has_permissions(administrator=True)
    async def leave_dm_dis(self, ctx, *, name: str = None): 
        self._block_global_error(ctx)
        if not name: return await self.send_error_v2(ctx, show_usage=True)
        await self._toggle_bool(ctx, name, "dm_greet", 0)

    @leave.group(name="ping", invoke_without_command=True)
    @commands.has_permissions(administrator=True)
    async def leave_ping(self, ctx):
        self._block_global_error(ctx)
        if ctx.invoked_subcommand is None:
            if ctx.subcommand_passed: return await self.send_error_v2(ctx, f"Invalid command: `{ctx.subcommand_passed}`")
            cmds = [
                {"name": f"{ctx.prefix}gleave ping enable <name>", "desc": "Ping the user when they leave."},
                {"name": f"{ctx.prefix}gleave ping disable <name>", "desc": "Disable pinging."}
            ]
            await self.send_subcommand_help(ctx, "Leave Ping", cmds)

    @leave_ping.command(name="enable", usage="<name>")
    @commands.has_permissions(administrator=True)
    async def leave_ping_en(self, ctx, *, name: str = None): 
        self._block_global_error(ctx)
        if not name: return await self.send_error_v2(ctx, show_usage=True)
        await self._toggle_bool(ctx, name, "mention_user", 1)
        
    @leave_ping.command(name="disable", usage="<name>")
    @commands.has_permissions(administrator=True)
    async def leave_ping_dis(self, ctx, *, name: str = None): 
        self._block_global_error(ctx)
        if not name: return await self.send_error_v2(ctx, show_usage=True)
        await self._toggle_bool(ctx, name, "mention_user", 0)

    @leave.group(name="autodelete", aliases=["autodel", "adel"], invoke_without_command=True)
    @commands.has_permissions(administrator=True)
    async def leave_autodelete(self, ctx):
        self._block_global_error(ctx)
        if ctx.invoked_subcommand is None:
            if ctx.subcommand_passed: return await self.send_error_v2(ctx, f"Invalid command: `{ctx.subcommand_passed}`")
            cmds = [
                {"name": f"{ctx.prefix}gleave autodelete enable <name> <time>", "desc": "Automatically delete the message after time (e.g. 10s, 2m)."},
                {"name": f"{ctx.prefix}gleave autodelete disable <name>", "desc": "Turn off auto-delete."}
            ]
            await self.send_subcommand_help(ctx, "Leave Autodelete", cmds)

    @leave_autodelete.command(name="enable", usage="<name> <time>")
    @commands.has_permissions(administrator=True)
    async def leave_autodelete_enable(self, ctx, name: str = None, time: str = None): 
        self._block_global_error(ctx)
        if not name or not time: return await self.send_error_v2(ctx, show_usage=True)
        seconds = 0
        if time.endswith("s"): seconds = int(time[:-1])
        elif time.endswith("m"): seconds = int(time[:-1]) * 60
        else: return await self.send_error_v2(ctx, "Invalid format. Use `s` for seconds or `m` for minutes.")
        val = seconds if seconds > 0 else None
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("UPDATE multi_leave SET autodel = ? WHERE guild_id = ? AND name = ?", (val, ctx.guild.id, name))
            await db.commit()
        await self.send_v2(ctx, f"{E_TICK} Auto delete for `{name}` set to **{seconds}s**.")
        
    @leave_autodelete.command(name="disable", usage="<name>")
    @commands.has_permissions(administrator=True)
    async def leave_autodelete_disable(self, ctx, *, name: str = None): 
        self._block_global_error(ctx)
        if not name: return await self.send_error_v2(ctx, show_usage=True)
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("UPDATE multi_leave SET autodel = NULL WHERE guild_id = ? AND name = ?", (ctx.guild.id, name))
            await db.commit()
        await self.send_v2(ctx, f"{E_TICK} Auto delete for `{name}` turned off.")

    @leave.command(name="clone", usage="<server_id>")
    @commands.has_permissions(administrator=True)
    async def leave_clone(self, ctx, server_id: int = None):
        self._block_global_error(ctx)
        if not server_id: return await self.send_error_v2(ctx, show_usage=True)
        if not await self._is_premium(ctx.guild.id): return await self.send_error_v2(ctx, "**Cloning is a Premium Feature.**", show_usage=False)
        await self.send_v2(ctx, "<a:discordchristmas:1504469421819826258> Fetching server data... (Cloning requires target server admin approval).")

    async def _save_data(self, guild_id, setup_name, typ, msg, embed_data):
        async with aiosqlite.connect(DB_PATH) as db:
            cur = await db.execute("SELECT channel_id, autodel, enabled, dm_greet, mention_user, buttons FROM multi_leave WHERE guild_id = ? AND name = ?", (guild_id, setup_name))
            ex = await cur.fetchone()
            ch_id, autodel, enabled, dm, ping, btns = ex if ex else (None, None, 1, 0, 1, None)
            
            await db.execute("""
            INSERT OR REPLACE INTO multi_leave (guild_id, name, w_type, w_msg, channel_id, embed_data, autodel, enabled, dm_greet, mention_user, buttons)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (guild_id, setup_name, typ, msg, ch_id, json.dumps(embed_data) if embed_data else None, autodel, enabled, dm, ping, btns))
            await db.commit()

    async def _run_simple_setup(self, ctx, setup_name, existing_msg=None):
        v = LayoutView(); c = Container(accent_color=INV_COLOR); c.add_item(TextDisplay(f"Current: {existing_msg}\n\nEnter your simple text message here:")); v.add_item(c)
        await ctx.send(view=v)
        try:
            msg = await self.bot.wait_for("message", timeout=300, check=lambda m: m.author == ctx.author and m.channel == ctx.channel)
            await self._save_data(ctx.guild.id, setup_name, "simple", msg.content, None)
            await self.send_v2(ctx, f"{E_TICK} Simple message configured! Use `gleave channel add {setup_name} <#channel>` to set target.")
        except: pass

    async def _run_embed_setup(self, ctx, setup_name, existing_data=None):
        view = EmbedBuilderView(self, ctx, setup_name, existing_data)
        view.message = await ctx.send(view=view)

    async def _run_image_setup(self, ctx, setup_name, existing_data=None):
        view = ImageCardBuilderView(self, ctx, setup_name, existing_data)
        view.message = await ctx.send(view=view)

async def setup(bot):
    await bot.add_cog(LeaveSystem(bot))