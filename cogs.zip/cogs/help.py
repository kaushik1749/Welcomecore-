import discord
from discord.ext import commands

# ==========================================
#  __  __ _____ ____      _    
#  \ \/ /|_   _|  _ \    / \   
#   \  /   | | | |_) |  / _ \  
#   /  \   | | |  _ <  / ___ \ 
#  /_/\_\  |_| |_| \_\/_/   \_\
# ==========================================

class HelpCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="help", description="Shows the help menu with all commands")
    async def help(self, ctx)
        total_commands_count = len(set(self.bot.walk_commands()))
        
        embed = discord.Embed(
            title="📊 Bot Help Menu",
            description=(
                f"**Total Commands:** `{total_commands_count}`"
            ),
            color=discord.Color.from_rgb(43, 45, 49) 
        )

        embed.add_field(
            name="💎 Premium Commands",
            value="`premium redeem`, `premium status`, `premium trial`, `premium setav`, `premium setbanner`, `premium setnick`, `premium setseparator`, `premium reset`",
            inline=False
        )


        embed.add_field(
            name="👋 Greet (Welcome) Commands",
            value="`greet create`, `greet edit`, `greet delete`, `greet list`, `greet test`, `greet enable`, `greet disable`, `greet variables`, `greet clone`",
            inline=False
        )

        embed.add_field(
            name="⚙️ Greet Customization & Channels",
            value="`greet channel add`, `greet channel reset`, `greet dm`, `greet ping`, `greet autodelete`, `greet button add`, `greet button remove`, `greet autorole`",
            inline=False
        )

        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        
        embed.set_footer(
            text=f"Requested by {ctx.author.display_name} • @XTRA TEAM", 
            icon_url=ctx.author.display_avatar.url
        )

        await ctx.send(embed=embed)

async def setup(bot):
    bot.remove_command("help") 
    await bot.add_cog(HelpCommand(bot))