from __future__ import annotations
import os
import discord
from discord.ext import commands, tasks
import aiosqlite
import datetime
import random
import string
import asyncio
import base64
import aiohttp
import types
from typing import Optional

OWNER_IDS = [1008243358902263929] 

from discord.ui import Button, LayoutView, Container, TextDisplay, Separator, ActionRow

INV_COLOR     = 0x2b2d31
ERROR_COLOR   = 0xff4444
SUCCESS_COLOR = 0x43b581
WARNING_COLOR = 0xf5a623
INFO_COLOR    = 0x8ec6ff

DB_PATH = "db/premium.db"
MSG_DB_PATH = "db/messages.db"
LOG_CHANNEL_ID = 1502302925068963840
TRIAL_CHANNEL_ID = 1499435473209397329
CB = "```"

E = {
    "arrow":   "<:RightArrow:1511137811418448006>",
    "premium": "<:emojigg_Dot:1512135490244055070>",
    "tick":    "<a:xtra_tick:1461751725424771138>",
    "cross":   "<a:xtra_cross:1461758174892916799>",
    "crown":   "<:emojigg_Dot:1512135490244055070>",
    "star":    "<:emojigg_Dot:1512135490244055070>",
    "shield":  "<:emojigg_Dot:1512135490244055070>",
    "fire":    "<:emojigg_Dot:1512135490244055070>",
    "loading": "<:emojigg_Dot:1512135490244055070>",
    "dot":     "<:emojigg_Dot:1512135490244055070>"
}

def generate_code(length: int = 16) -> str:
    chars = string.ascii_uppercase + string.digits
    raw = "".join(random.choices(chars, k=length))
    return "-".join(raw[i:i+4] for i in range(0, length, 4))

def safe_url(url):
    if url and str(url).startswith("http"): return str(url)
    return None

async def get_branding(ctx=None, guild=None, bot=None):
    target_guild = guild if guild else (ctx.guild if ctx else None)
    target_bot = bot if bot else (ctx.bot if ctx else None)
    bot_name = target_bot.user.name if target_bot and target_bot.user else "System"
    bot_icon = target_bot.user.display_avatar.url if target_bot and target_bot.user else None
    is_premium = False
    
    if not target_guild: return bot_name, safe_url(bot_icon), is_premium

    db_paths = ["db/premium.db", "premium.db", "../premium.db", "data/premium.db", "core/premium.db"]
    for path in db_paths:
        if os.path.exists(path):
            try:
                async with aiosqlite.connect(path) as db:
                    async with db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='premium_guilds'") as cursor:
                        if await cursor.fetchone():
                            async with db.execute("SELECT 1 FROM premium_guilds WHERE guild_id = ? OR guild_id = ?", (target_guild.id, str(target_guild.id))) as check_cur:
                                if await check_cur.fetchone():
                                    is_premium = True
                break
            except Exception: continue
                
    if is_premium and target_guild:
        bot_name = target_guild.me.display_name if target_guild.me else bot_name
        bot_icon = target_guild.me.display_avatar.url if target_guild.me else bot_icon
        
    return bot_name, safe_url(bot_icon), is_premium

class LayoutListPaginator(LayoutView):
    def __init__(self, ctx, title: str, entries: list, per_page: int=10, color: int=INV_COLOR):
        super().__init__(timeout=180)
        self.ctx = ctx
        self.title = title
        self.entries = entries
        self.per_page = per_page
        self.color = color
        self.current_page = 1
        self.max_pages = max(1, (len(self.entries) + self.per_page - 1) // self.per_page)
        
        self.b_first = Button(label="𝐅ɪʀꜱᴛ", style=discord.ButtonStyle.secondary)
        self.b_prev = Button(label="𝐏ʀᴇᴠ", style=discord.ButtonStyle.secondary)
        self.b_next = Button(label="𝐍ᴇxᴛ", style=discord.ButtonStyle.secondary)
        self.b_last = Button(label="𝐋ᴀꜱᴛ", style=discord.ButtonStyle.secondary)
        self.b_del = Button(label="𝐂ʟᴏꜱᴇ", style=discord.ButtonStyle.danger)

        self.b_first.callback = self.cb_first
        self.b_prev.callback = self.cb_prev
        self.b_next.callback = self.cb_next
        self.b_last.callback = self.cb_last
        self.b_del.callback = self.cb_del
        self._build_ui()

    def _build_ui(self):
        self.clear_items()
        start = (self.current_page - 1) * self.per_page
        end = start + self.per_page
        page_entries = self.entries[start:end]

        c = Container(accent_color=self.color)
        c.add_item(TextDisplay(f"### {self.title}"))
        c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
        
        txt = "\n".join(page_entries)
        c.add_item(TextDisplay(txt))
        
        c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
        c.add_item(TextDisplay(f"-# Page {self.current_page}/{self.max_pages} | Requested by **{self.ctx.author.display_name}**"))
        
        self.b_first.disabled = self.b_prev.disabled = (self.current_page == 1)
        self.b_next.disabled = self.b_last.disabled = (self.current_page == self.max_pages)

        c.add_item(ActionRow(self.b_first, self.b_prev, self.b_next, self.b_last))
        c.add_item(ActionRow(self.b_del))
        self.add_item(c)

    async def _update_view(self, i: discord.Interaction):
        if i.user != self.ctx.author: return await i.response.defer()
        self._build_ui()
        await i.response.edit_message(view=self)

    async def cb_first(self, i): self.current_page = 1; await self._update_view(i)
    async def cb_prev(self, i): self.current_page -= 1; await self._update_view(i)
    async def cb_next(self, i): self.current_page += 1; await self._update_view(i)
    async def cb_last(self, i): self.current_page = self.max_pages; await self._update_view(i)
    async def cb_del(self, i): 
        if i.user == self.ctx.author:
            try: await i.message.delete()
            except discord.NotFound: pass
        else: await i.response.defer()

class PremiumHelpMenuV2(LayoutView):
    def __init__(self, ctx, bot_name: str, is_owner: bool, is_premium: bool):
        super().__init__(timeout=180)
        self.ctx = ctx
        self.bot_name = bot_name
        self.current_page = 1
        self.per_page = 5
        
        pref = ctx.prefix if ctx.prefix else ""
        
        self.cmds = [
            {"name": f"{pref}premium redeem <code>", "desc": "Redeem a premium code for this server."},
            {"name": f"{pref}premium status", "desc": "Check current premium status of this server."},
            {"name": f"{pref}premium trial", "desc": "Claim a free 7-day premium trial."}
        ]

        if is_premium:
            self.cmds.insert(0, {"name": f"{pref}premium setav <url>", "desc": "Set a custom server-specific bot avatar."})
            self.cmds.insert(1, {"name": f"{pref}premium setbanner <url>", "desc": "Set a custom server-specific bot banner."})
            self.cmds.insert(2, {"name": f"{pref}premium setnick <name>", "desc": "Set a custom nickname for the bot."})
            self.cmds.insert(3, {"name": f"{pref}premium setseparator <text>", "desc": "Set a custom separator for embeds."})
            self.cmds.insert(4, {"name": f"{pref}premium reset", "desc": "Reset all profile settings to default."})

        if is_owner:
            self.cmds.extend([
                {"name": f"{pref}premium add <guild_id> <time>", "desc": "[Owner] Manually add premium to a guild."},
                {"name": f"{pref}premium remove <guild_id>", "desc": "[Owner] Remove premium from a guild."},
                {"name": f"{pref}premium list", "desc": "[Owner] List all premium guilds."},
                {"name": f"{pref}premium gen <time>", "desc": "[Owner] Generate a premium code."},
                {"name": f"{pref}premium codes", "desc": "[Owner] View all generated codes."},
                {"name": f"{pref}trialsetup", "desc": "[Owner] Setup the trial instructions channel."}
            ])
        
        self.max_pages = max(1, (len(self.cmds) + self.per_page - 1) // self.per_page)
        
        self.b_first = Button(label="𝐅ɪʀꜱᴛ", style=discord.ButtonStyle.secondary, custom_id="p_first")
        self.b_prev = Button(label="𝐏ʀᴇᴠ", style=discord.ButtonStyle.secondary, custom_id="p_prev")
        self.b_next = Button(label="𝐍ᴇxᴛ", style=discord.ButtonStyle.secondary, custom_id="p_next")
        self.b_last = Button(label="𝐋ᴀꜱᴛ", style=discord.ButtonStyle.secondary, custom_id="p_last")
        self.b_del = Button(label="𝐂ʟᴏꜱᴇ", style=discord.ButtonStyle.danger, custom_id="p_del")

        self.b_first.callback = self.cb_first
        self.b_prev.callback = self.cb_prev
        self.b_next.callback = self.cb_next
        self.b_last.callback = self.cb_last
        self.b_del.callback = self.cb_del
        self._build_ui()

    def _build_ui(self):
        self.clear_items()
        start = (self.current_page - 1) * self.per_page
        end = start + self.per_page
        page_cmds = self.cmds[start:end]

        c = Container(accent_color=INV_COLOR)
        header = f"### {self.bot_name} — Premium \n**{len(self.cmds)}** commands available"
        c.add_item(TextDisplay(header))
        c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
        c.add_item(TextDisplay(f"{CB}yaml\n<..> required | [..] optional\n{CB}"))
        c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
        
        cmds_text = ""
        for cmd in page_cmds:
            cmds_text += f"`{cmd['name']}`\n> {E['arrow']} {cmd['desc']}\n\n"
            
        c.add_item(TextDisplay(cmds_text.strip()))
        c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
        
        footer = f"-# Page {self.current_page}/{self.max_pages} | Requested by **{self.ctx.author.display_name}**"
        c.add_item(TextDisplay(footer))
        c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
        
        self.b_first.disabled = (self.current_page == 1)
        self.b_prev.disabled = (self.current_page == 1)
        self.b_next.disabled = (self.current_page == self.max_pages)
        self.b_last.disabled = (self.current_page == self.max_pages)

        c.add_item(ActionRow(self.b_first, self.b_prev, self.b_next, self.b_last))
        c.add_item(ActionRow(self.b_del))
        self.add_item(c)

    async def _update_view(self, i):
        if i.user != self.ctx.author: return await i.response.defer()
        self._build_ui()
        await i.response.edit_message(view=self)

    async def cb_first(self, i): self.current_page = 1; await self._update_view(i)
    async def cb_prev(self, i): self.current_page -= 1; await self._update_view(i)
    async def cb_next(self, i): self.current_page += 1; await self._update_view(i)
    async def cb_last(self, i): self.current_page = self.max_pages; await self._update_view(i)
    async def cb_del(self, i: discord.Interaction): 
        if i.user == self.ctx.author:
            try: await i.message.delete()
            except discord.NotFound: pass
        else: await i.response.defer()

class Premium(commands.Cog):
    def __init__(self, client):
        self.client = client
        self.client.loop.create_task(self.setup_database())
        self.check_expiries.start()

    async def setup_database(self):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("CREATE TABLE IF NOT EXISTS premium_guilds (guild_id INTEGER PRIMARY KEY, expiry_time TEXT, added_by INTEGER)")
            await db.execute("CREATE TABLE IF NOT EXISTS premium_profiles (guild_id INTEGER PRIMARY KEY, bio TEXT, separator TEXT)")
            await db.execute("CREATE TABLE IF NOT EXISTS trial_claims (guild_id INTEGER PRIMARY KEY, claimed_at TEXT, claimed_by INTEGER)")
            await db.execute("CREATE TABLE IF NOT EXISTS premium_codes (code TEXT PRIMARY KEY, duration TEXT, created_by INTEGER, created_at TEXT, used_by INTEGER DEFAULT NULL, used_at TEXT DEFAULT NULL, used_guild INTEGER DEFAULT NULL)")
            await db.commit()

    def cog_unload(self):
        self.check_expiries.cancel()

    def _block_global_error(self, ctx):
        setattr(ctx, 'handled', True)
        if hasattr(ctx, 'command') and ctx.command:
            async def dummy_on_error(*args, **kwargs): pass
            ctx.command.on_error = dummy_on_error

    def _build_layout_payload(self, head: str, desc: str, color: int):
        v = LayoutView()
        c = Container(accent_color=color)
        c.add_item(TextDisplay(f"### {head}"))
        c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
        c.add_item(TextDisplay(desc))
        v.add_item(c)
        return v

    async def send_v2(self, ctx, head: str, desc: str, color=INV_COLOR):
        self._block_global_error(ctx)
        v = self._build_layout_payload(head, desc, color)
        try:
            if hasattr(ctx, "reply"): await ctx.reply(view=v, mention_author=False)
            else: await ctx.send(view=v)
        except: pass

    async def send_error_v2(self, ctx, msg="You are missing one or more\nrequired parameters!", show_usage=False):
        self._block_global_error(ctx)
        bot_name, _, _ = await get_branding(ctx)
        
        v = LayoutView()
        c = Container(accent_color=ERROR_COLOR)
        
        header = f"### {E['cross']} {bot_name} Missing Argument !" if show_usage else f"### {E['cross']} {bot_name} Error"
        c.add_item(TextDisplay(header))
        c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=True))
        c.add_item(TextDisplay(msg))
        
        if show_usage:
            cmd_name = f"{getattr(ctx, 'prefix', '/')}{ctx.command.qualified_name}" if hasattr(ctx, 'command') and ctx.command else "command"
            usage = ctx.command.usage if hasattr(ctx, 'command') and ctx.command and ctx.command.usage else ""
            c.add_item(Separator(spacing=discord.SeparatorSpacing.small, visible=False))
            c.add_item(TextDisplay(f"> {E['arrow']} **Correct Usage ~**\n{CB}\n{cmd_name} {usage}\n{CB}"))
            
        v.add_item(c)
        try:
            if hasattr(ctx, "reply"): return await ctx.reply(view=v, mention_author=False)
            else: return await ctx.send(view=v)
        except: pass

    async def cog_command_error(self, ctx, error):
        self._block_global_error(ctx)
        setattr(error, 'handled', True)
        
        if hasattr(ctx.command, 'on_error'): return
        if isinstance(error, commands.CommandInvokeError): error = error.original
            
        if isinstance(error, (commands.MissingRequiredArgument, commands.BadArgument)):
            await self.send_error_v2(ctx, show_usage=True)
        elif isinstance(error, commands.MissingPermissions):
            await self.send_error_v2(ctx, "You lack permissions to use this command.")
        elif isinstance(error, commands.NotOwner):
            await self.send_error_v2(ctx, "Only the **bot owner** can use this command.")
        else:
            await self.send_error_v2(ctx, show_usage=True)

    async def _to_base64(self, url: str) -> Optional[str]:
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as resp:
                    if resp.status == 200:
                        data = await resp.read()
                        ext = "gif" if ".gif" in url.lower() else "png"
                        return f"data:image/{ext};base64,{base64.b64encode(data).decode('utf-8')}"
        except Exception: pass
        return None

    def parse_duration(self, duration_str: str) -> Optional[datetime.timedelta]:
        if duration_str.lower() == "lifetime": return None
        import re
        units = {"s": "seconds", "m": "minutes", "h": "hours", "d": "days", "w": "weeks"}
        match = re.match(r"(\d+)(mo|[smhdwy])", duration_str.lower())
        if not match: return None
        amount, unit = int(match.group(1)), match.group(2)
        if unit == "mo": return datetime.timedelta(days=amount * 30)
        if unit == "y": return datetime.timedelta(days=amount * 365)
        if unit in units: return datetime.timedelta(**{units[unit]: amount})
        return None

    def _fmt_expiry(self, delta: Optional[datetime.timedelta]) -> str:
        if delta is None: return "Never"
        ts = int((datetime.datetime.utcnow() + delta).timestamp())
        return f"<t:{ts}:F>"

    async def is_premium(self, guild_id: int) -> bool:
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT 1 FROM premium_guilds WHERE guild_id = ?", (guild_id,)) as cursor:
                return await cursor.fetchone() is not None

    async def premium_req(self, ctx):
        await self.send_error_v2(ctx, "This command is only available for **Premium Guilds**.\nUse `premium redeem <code>` or contact the bot owner.")

    @tasks.loop(minutes=5)
    async def check_expiries(self):
        await self.client.wait_until_ready()
        async with aiosqlite.connect(DB_PATH) as db:
            now = datetime.datetime.utcnow().isoformat()
            async with db.execute("SELECT guild_id, added_by FROM premium_guilds WHERE expiry_time IS NOT NULL AND expiry_time <= ?", (now,)) as cursor:
                expired = await cursor.fetchall()

            for guild_id, added_by in expired:
                await db.execute("DELETE FROM premium_guilds WHERE guild_id = ?", (guild_id,))
                await db.execute("DELETE FROM premium_profiles WHERE guild_id = ?", (guild_id,))
                await db.commit()

                guild = self.client.get_guild(guild_id)
                if guild:
                    try: await guild.me.edit(nick=None)
                    except Exception: pass
                    try:
                        route = discord.http.Route("PATCH", f"/guilds/{guild_id}/members/@me")
                        await self.client.http.request(route, json={"avatar": None, "banner": None, "bio": ""})
                    except Exception: pass

                log_channel = self.client.get_channel(LOG_CHANNEL_ID)
                if log_channel:
                    v = self._build_layout_payload("Premium Expired", f"**Guild:** {guild.name if guild else 'Unknown'} (`{guild_id}`)\n**Status:** Premium Removed", ERROR_COLOR)
                    await log_channel.send(view=v)

    @commands.group(name="premium", invoke_without_command=True)
    async def premium_group(self, ctx: commands.Context):
        self._block_global_error(ctx)
        bot_name, _, is_premium = await get_branding(ctx)
        is_owner = ctx.author.id in OWNER_IDS
        view = PremiumHelpMenuV2(ctx, bot_name, is_owner, is_premium)
        await ctx.send(view=view)

    @premium_group.command(name="setav", usage="<url>")
    @commands.has_permissions(administrator=True)
    async def p_setav(self, ctx: commands.Context, url: str=None):
        if not url: return await self.send_error_v2(ctx, show_usage=True)
        if not await self.is_premium(ctx.guild.id): return await self.premium_req(ctx)
        v_loading = self._build_layout_payload("Processing...", f"{E['loading']} Downloading and processing image...", INFO_COLOR)
        msg = await ctx.reply(view=v_loading, mention_author=False)
        b64 = await self._to_base64(url)
        if not b64:
            return await msg.edit(view=self._build_layout_payload("Invalid URL", "Provide a valid image URL.", WARNING_COLOR))
        try:
            route = discord.http.Route("PATCH", f"/guilds/{ctx.guild.id}/members/@me")
            await self.client.http.request(route, json={"avatar": b64})
            bot_name, _, _ = await get_branding(ctx)
            await msg.edit(view=self._build_layout_payload(f"{E['tick']} {bot_name} Premium", "> <:RightArrow:1511137811418448006> Successfully updated my server avatar!", SUCCESS_COLOR))
        except Exception as e:
            await msg.edit(view=self._build_layout_payload("Error", f"Failed to update avatar: {e}", ERROR_COLOR))

    @premium_group.command(name="setbanner", usage="<url>")
    @commands.has_permissions(administrator=True)
    async def p_setbanner(self, ctx: commands.Context, url: str=None):
        if not url: return await self.send_error_v2(ctx, show_usage=True)
        if not await self.is_premium(ctx.guild.id): return await self.premium_req(ctx)
        v_loading = self._build_layout_payload("Processing...", f"{E['loading']} Downloading and processing banner...", INFO_COLOR)
        msg = await ctx.reply(view=v_loading, mention_author=False)
        b64 = await self._to_base64(url)
        if not b64:
            return await msg.edit(view=self._build_layout_payload("Invalid URL", "Provide a valid image URL.", WARNING_COLOR))
        try:
            route = discord.http.Route("PATCH", f"/guilds/{ctx.guild.id}/members/@me")
            await self.client.http.request(route, json={"banner": b64})
            bot_name, _, _ = await get_branding(ctx)
            await msg.edit(view=self._build_layout_payload(f"{E['tick']} {bot_name} Premium", "> <:RightArrow:1511137811418448006>  Successfully updated my server banner!", SUCCESS_COLOR))
        except Exception as e:
            await msg.edit(view=self._build_layout_payload("Error", f"Failed to update banner: {e}", ERROR_COLOR))

    @premium_group.command(name="setnick", usage="<name>")
    @commands.has_permissions(administrator=True)
    async def p_setnick(self, ctx: commands.Context, *, name: str=None):
        if not name: return await self.send_error_v2(ctx, show_usage=True)
        if not await self.is_premium(ctx.guild.id): return await self.premium_req(ctx)
        try:
            await ctx.guild.me.edit(nick=name)
            bot_name, _, _ = await get_branding(ctx)
            await self.send_v2(ctx, f"{E['tick']} {bot_name} Premium", "> <:RightArrow:1511137811418448006> Successfully updated my server nickname!", SUCCESS_COLOR)
        except Exception as e:
            await self.send_v2(ctx, "Error", f"Failed to update nickname: {e}", ERROR_COLOR)

    @premium_group.command(name="setseparator", usage="<text>")
    @commands.has_permissions(administrator=True)
    async def p_setseparator(self, ctx: commands.Context, *, text: str=None):
        if not text: return await self.send_error_v2(ctx, show_usage=True)
        if not await self.is_premium(ctx.guild.id): return await self.premium_req(ctx)
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("INSERT OR REPLACE INTO premium_profiles (guild_id, bio, separator) VALUES (?, (SELECT bio FROM premium_profiles WHERE guild_id=?), ?)", (ctx.guild.id, ctx.guild.id, text))
            await db.commit()
        bot_name, _, _ = await get_branding(ctx)
        await self.send_v2(ctx, f"{E['tick']} {bot_name} Premium", "> <:RightArrow:1511137811418448006> Successfully updated my layout separator!", SUCCESS_COLOR)

    @premium_group.command(name="reset")
    @commands.has_permissions(administrator=True)
    async def p_reset(self, ctx: commands.Context):
        if not await self.is_premium(ctx.guild.id): return await self.premium_req(ctx)
        try: await ctx.guild.me.edit(nick=None)
        except Exception: pass
        try:
            route = discord.http.Route("PATCH", f"/guilds/{ctx.guild.id}/members/@me")
            await self.client.http.request(route, json={"avatar": None, "banner": None, "bio": ""})
        except Exception: pass
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("DELETE FROM premium_profiles WHERE guild_id = ?", (ctx.guild.id,))
            await db.commit()
        bot_name, _, _ = await get_branding(ctx)
        await self.send_v2(ctx, f"{E['tick']} {bot_name} Premium", "> <:RightArrow:1511137811418448006> Successfully reset my server profile back to default!", SUCCESS_COLOR)

    @premium_group.command(name="add", usage="<guild_id> <duration>")
    async def premium_add(self, ctx: commands.Context, guild_id: int=None, duration: str=None):
        if ctx.author.id not in OWNER_IDS: return await self.send_error_v2(ctx, "Only the **bot owner** can use this command.")
        if not guild_id or not duration: return await self.send_error_v2(ctx, show_usage=True)
        delta = self.parse_duration(duration)
        if delta is None and duration.lower() != "lifetime":
            return await self.send_v2(ctx, "Invalid Duration", f"Could not parse `{duration}`.", WARNING_COLOR)
        expiry = (datetime.datetime.utcnow() + delta).isoformat() if delta else None
        expiry_display = self._fmt_expiry(delta)
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("INSERT OR REPLACE INTO premium_guilds (guild_id, expiry_time, added_by) VALUES (?, ?, ?)", (guild_id, expiry, ctx.author.id))
            await db.commit()
        guild = self.client.get_guild(guild_id)
        guild_name = guild.name if guild else "Unknown Guild"
        await self.send_v2(ctx, "Premium Added", f"**Guild:** {guild_name} (`{guild_id}`)\n**Expires:** {expiry_display}\n**Added By:** {ctx.author.mention}", SUCCESS_COLOR)

    @premium_group.command(name="remove", usage="<guild_id>")
    async def premium_remove(self, ctx: commands.Context, guild_id: int=None):
        if ctx.author.id not in OWNER_IDS: return await self.send_error_v2(ctx, "Only the **bot owner** can use this command.")
        if not guild_id: return await self.send_error_v2(ctx, show_usage=True)
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("DELETE FROM premium_guilds WHERE guild_id = ?", (guild_id,))
            await db.execute("DELETE FROM premium_profiles WHERE guild_id = ?", (guild_id,))
            await db.commit()
        guild = self.client.get_guild(guild_id)
        if guild:
            try: await guild.me.edit(nick=None)
            except Exception: pass
            try:
                route = discord.http.Route("PATCH", f"/guilds/{guild_id}/members/@me")
                await self.client.http.request(route, json={"avatar": None, "banner": None, "bio": ""})
            except Exception: pass
        guild_name = guild.name if guild else "Unknown Guild"
        await self.send_v2(ctx, "Premium Removed", f"**Guild:** {guild_name} (`{guild_id}`)\nPremium has been removed successfully.", SUCCESS_COLOR)

    @premium_group.command(name="list")
    async def premium_list(self, ctx: commands.Context):
        if ctx.author.id not in OWNER_IDS: return await self.send_error_v2(ctx, "Only the **bot owner** can use this command.")
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT guild_id, expiry_time FROM premium_guilds") as cursor:
                rows = await cursor.fetchall()
        if not rows: return await self.send_v2(ctx, "No Premium Guilds", "No premium guilds found in database.", WARNING_COLOR)
        entries = []
        for gid, expiry in rows:
            expiry_str = f"<t:{int(datetime.datetime.fromisoformat(expiry).timestamp())}:R>" if expiry else "Lifetime"
            guild = self.client.get_guild(gid)
            guild_name = f" — **{guild.name}**" if guild else ""
            entries.append(f"> `{gid}`{guild_name} | {expiry_str}")
        view = LayoutListPaginator(ctx, f"Premium Guilds [{len(rows)}]", entries, color=INV_COLOR)
        await ctx.send(view=view)

    @premium_group.command(name="status")
    @commands.has_permissions(administrator=True)
    async def premium_status(self, ctx: commands.Context):
        self._block_global_error(ctx)
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT expiry_time, added_by FROM premium_guilds WHERE guild_id = ?", (ctx.guild.id,)) as cursor:
                row = await cursor.fetchone()
        if not row:
            desc = f"This server does **not** have Premium.\n\nUse `{ctx.prefix}premium redeem <code>` to activate."
            return await self.send_v2(ctx, "Premium Status", desc, WARNING_COLOR)
        expiry, added_by = row
        if expiry:
            ts = int(datetime.datetime.fromisoformat(expiry).timestamp())
            expiry_display = f"<t:{ts}:F>\n> *(expires <t:{ts}:R>)*"
        else:
            expiry_display = "**Lifetime** — Never expires"
        adder = self.client.get_user(added_by)
        adder_str = f"{adder.mention}" if adder else f"`{added_by}`"
        desc = f"This server has **Active Premium**!\n\n**Server:** {ctx.guild.name} (`{ctx.guild.id}`)\n\n**Expires:** {expiry_display}\n\n**Granted By:** {adder_str}"
        await self.send_v2(ctx, "Premium Status", desc, SUCCESS_COLOR)

    @premium_group.command(name="gen", usage="<duration>")
    async def premium_gen(self, ctx: commands.Context, duration: str=None):
        if ctx.author.id not in OWNER_IDS: return await self.send_error_v2(ctx, "Only the **bot owner** can use this command.")
        if not duration: return await self.send_error_v2(ctx, show_usage=True)
        delta = self.parse_duration(duration)
        if delta is None and duration.lower() != "lifetime":
            return await self.send_v2(ctx, "Invalid Duration", f"Could not parse `{duration}`.", WARNING_COLOR)
        code = generate_code()
        now = datetime.datetime.utcnow().isoformat()
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("INSERT INTO premium_codes (code, duration, created_by, created_at) VALUES (?, ?, ?, ?)", (code, duration, ctx.author.id, now))
            await db.commit()
        expiry_display = self._fmt_expiry(delta)
        desc = f"**Code:**\n{CB}\n{code}\n{CB}\n**Duration:** `{duration}` ({expiry_display})\n\n**Usage:** `{ctx.prefix}premium redeem {code}`"
        await self.send_v2(ctx, "Premium Code Generated", desc, INV_COLOR)

    @premium_group.command(name="redeem", usage="<code>")
    @commands.has_permissions(administrator=True)
    async def premium_redeem(self, ctx: commands.Context, code: str=None):
        if not code: return await self.send_error_v2(ctx, show_usage=True)
        code = code.upper().strip()
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT duration, used_by FROM premium_codes WHERE code = ?", (code,)) as cursor:
                row = await cursor.fetchone()
        if not row: return await self.send_v2(ctx, "Invalid Code", f"The code `{code}` is **invalid** or does not exist.", ERROR_COLOR)
        duration, used_by = row
        if used_by is not None: return await self.send_v2(ctx, "Code Already Used", "This code has already been **redeemed**.", WARNING_COLOR)
        delta = self.parse_duration(duration)
        expiry = (datetime.datetime.utcnow() + delta).isoformat() if delta else None
        expiry_display = self._fmt_expiry(delta)
        now = datetime.datetime.utcnow().isoformat()
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("UPDATE premium_codes SET used_by = ?, used_at = ?, used_guild = ? WHERE code = ?", (ctx.author.id, now, ctx.guild.id, code))
            await db.execute("INSERT OR REPLACE INTO premium_guilds (guild_id, expiry_time, added_by) VALUES (?, ?, ?)", (ctx.guild.id, expiry, ctx.author.id))
            await db.commit()
        desc = f"**Premium has been activated for this server!**\n\n**Server:** {ctx.guild.name}\n**Expires:** {expiry_display}\n**Redeemed By:** {ctx.author.mention}"
        await self.send_v2(ctx, "Premium Activated!", desc, SUCCESS_COLOR)

    @premium_group.command(name="codes")
    async def premium_codes(self, ctx: commands.Context):
        if ctx.author.id not in OWNER_IDS: return await self.send_error_v2(ctx, "Only the **bot owner** can use this command.")
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT code, duration, used_by, used_guild FROM premium_codes ORDER BY created_at DESC") as cursor:
                rows = await cursor.fetchall()
        if not rows: return await self.send_v2(ctx, "No Codes", "No premium codes have been generated yet.", INFO_COLOR)
        entries = [f"> `{code}` | `{duration}` | {'Used — Guild `'+str(used_guild)+'`' if used_by else 'Available'}" for code, duration, used_by, used_guild in rows]
        view = LayoutListPaginator(ctx, f"Premium Codes [{len(rows)}]", entries, color=INV_COLOR)
        await ctx.send(view=view)

    def _build_trial_instructions_layout(self):
        desc = (
            "**Get 7 Days of Premium Absolutely FREE!**\n\n"
            "**How to Claim:**\n"
            "1. Type your **Server ID** in this channel\n"
            "2. Bot will automatically activate premium\n"
            "3. Enjoy all premium features for 7 days!\n\n"
            "**Rules:**\n"
            "• One trial per server only\n"
            "• Cannot claim again after expiry\n"
            "• Premium auto-removes after 7 days\n\n"
            "**Features Included:**\n"
            "• Server Backup & Restore\n"
            "• Message Leaderboards\n"
            "• Exclusive Admin Tools\n"
            "• Custom Bot Profile"
        )
        return self._build_layout_payload("Xtra 7-Day Free Trial", desc, INV_COLOR)

    async def _has_claimed_trial(self, guild_id: int) -> bool:
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT 1 FROM trial_claims WHERE guild_id = ?", (guild_id,)) as cursor:
                return await cursor.fetchone() is not None

    async def _claim_trial(self, guild_id: int, user_id: int) -> bool:
        try:
            expiry = (datetime.datetime.utcnow() + datetime.timedelta(days=7)).isoformat()
            async with aiosqlite.connect(DB_PATH) as db:
                await db.execute("INSERT INTO trial_claims (guild_id, claimed_at, claimed_by) VALUES (?, ?, ?)", (guild_id, datetime.datetime.utcnow().isoformat(), user_id))
                await db.execute("INSERT OR REPLACE INTO premium_guilds (guild_id, expiry_time, added_by) VALUES (?, ?, ?)", (guild_id, expiry, user_id))
                await db.commit()
            return True
        except Exception: return False

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild or not message.content: return
        
        # ── TRIAL SYSTEM ONLY ──
        if message.channel.id == TRIAL_CHANNEL_ID:
            content = message.content.strip()
            if not content.isdigit(): return
            guild_id = int(content)
            
            if await self._has_claimed_trial(guild_id):
                v = self._build_layout_payload("Trial Already Claimed", "**This server has already claimed the free trial!**\n\nEach server can only claim once.", WARNING_COLOR)
                await message.reply(view=v, delete_after=10)
                await message.delete(delay=5)
                return
                
            success = await self._claim_trial(guild_id, message.author.id)
            if success:
                expiry_timestamp = int((datetime.datetime.utcnow() + datetime.timedelta(days=7)).timestamp())
                desc = f"**7-Day Premium Trial Activated!**\n\n**Server ID:** `{guild_id}`\n**Expires:** <t:{expiry_timestamp}:F>\n**Claimed By:** {message.author.mention}\n\nEnjoy your premium features!"
                v_success = self._build_layout_payload("Premium Activated!", desc, SUCCESS_COLOR)
                await message.reply(view=v_success)
                
                log_channel = self.client.get_channel(LOG_CHANNEL_ID)
                if log_channel:
                    v_log = self._build_layout_payload("Trial Claimed", f"**Guild ID:** `{guild_id}`\n**Claimed By:** {message.author.mention} (`{message.author.id}`)\n**Expires:** <t:{expiry_timestamp}:F>\n**Type:** 7-Day Free Trial", SUCCESS_COLOR)
                    await log_channel.send(view=v_log)
                
                await message.delete()
                await asyncio.sleep(5)
                await message.channel.send(view=self._build_trial_instructions_layout())
            else:
                v_fail = self._build_layout_payload("Activation Failed", "Failed to activate premium.\nContact the bot owner for help.", ERROR_COLOR)
                await message.reply(view=v_fail, delete_after=10)
                await message.delete(delay=5)
            return

    @premium_group.command(name="trialsetup")
    async def trial_setup(self, ctx: commands.Context):
        if ctx.author.id not in OWNER_IDS: return await self.send_error_v2(ctx, "Only the **bot owner** can use this command.")
        self._block_global_error(ctx)
        if ctx.channel.id != TRIAL_CHANNEL_ID: return await self.send_error_v2(ctx, "This command only works in the trial channel!")
        await ctx.send(view=self._build_trial_instructions_layout())
        await ctx.message.delete()

async def setup(client):
    await client.add_cog(Premium(client))